from django.shortcuts import render,redirect
from django.http import HttpResponse
from django.template import loader
from django.contrib import messages
from django.contrib.auth.models import User
from django.contrib.auth import authenticate,login,logout

from django.contrib.auth.forms import AuthenticationForm #add this

from reg.forms import CustomerForm
from reg.models import Customer
# Create your views here.

def home(request):
    return render(request,'home.html')

def reg(request):
    template=loader.get_template('Index Page.html')

    return HttpResponse(template.render())

def contact(request):
    template=loader.get_template('contact.html')

    return HttpResponse(template.render())

def about(request):
    template=loader.get_template('about.html')

    return HttpResponse(template.render())

# def register(request):
#     firstname = request.POST.get('first_name')
#     lastname = request.POST.get('last_name')

#     email=request.POST.get('email')
#     password=request.POST.get('password')
#     contact=request.POST.get('contact')
#     address= request.POST.get('address')

#     template=loader.get_template('data.html')
#     context = {
#         'Firstname':firstname ,'Lastname':lastname,'Email':email ,'Password':password,
#         'Contact': contact ,'Address': address,
#     }
#     return HttpResponse(template.render(context,request))

#     return render(request,'data.html',{'Firstname':firstname ,'Lastname':lastname,
#     'Email':email,'Password':password,'Contact': contact ,'Address': address})

def register(request):
    if request.method == "POST":
        username=request.POST['username']
        firstname=request.POST['firstname']
        lastname=request.POST['lastname']
        email=request.POST['email']
        password=request.POST['pass1']
        contact=request.POST['contact']
        address=request.POST['address']

        myuser = User.objects.create_user(username,email,password)
        myuser.first_name = firstname
        myuser.last_name = lastname
        myuser.save()
        

        messages.success(request,'Registration Successfull')
        return redirect("/login")

    return render(request,"Registerpage.html")
# Register using Forms 
    # if request.method == "POST":
    #     form = CustomerForm(request.POST)
    #     if form.is_valid():
    #         try:
    #             form.save()
    #             return redirect("login/")
    #         except:
    #             pass
    # else:
    #     form=CustomerForm()
    # return render(request,'register.html',{'form':form}) 

def user_login(request):
    
#userDefined
    if request.method == "POST":
        username = request.POST['username']
        password = request.POST['pass1']

        user = authenticate(request,username= username,password= password)
        if user is not None:
            login(request,user)

            fname=user.first_name
            return render(request,"home.html",{'firstname':fname})
        else:

            messages.error(request,'invalid credentials')
            return redirect("")
    else:
        return render(request,'loginpage.html')

 
 
#          Using Forms for login
# if request.method == "POST":
    #     # form = AuthenticationForm(request.POST)
    #     # if form.is_valid():
    #     username=request.POST['username']
    #     password=request.POST['password']

    #     user=authenticate(request,username=username,password=password)
    #     if user is not None:
    #         login(request, user)
    #         messages.success(request,"your are logged in")
    #         return redirect('home/')
    #     else:
    #         messages.info(request,"Invalid username or password")
    #     # else:
    #     #     messages.error(request,"Invalid username or password")
    #     #     return HttpResponse("Hello Pritam")

    # form=AuthenticationForm()
    # return render(request,'loginpage.html',{"form":form})

def user_logout(request):
    logout(request)
    messages.success(request,"Logout Successful")
    return redirect("/")
        
  



   

    