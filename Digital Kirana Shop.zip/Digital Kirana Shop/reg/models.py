from django.db import models

# Create your models here.
class Customer(models.Model):
    firstname=models.CharField(max_length=50)
    lastname=models.CharField(max_length=50)
    username=models.CharField(max_length=50,null=True)
    email=models.EmailField()
    password=models.CharField(max_length=20)
    contact=models.CharField(max_length=10)
    address=models.CharField(max_length=200)

    class Meta:
        db_table = 'customer'
