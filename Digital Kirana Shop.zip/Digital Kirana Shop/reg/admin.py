from django.contrib import admin

from reg.models import Customer

# Register your models here.
class CustomerAdmin(admin.ModelAdmin):
  list_display = ('username','firstname','lastname','email','password','contact','address')
  
admin.site.register(Customer,CustomerAdmin)
